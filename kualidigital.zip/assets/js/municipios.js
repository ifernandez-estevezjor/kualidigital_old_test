var municipios = {
    "Estado de Mexico":[
        "Zumpango"
    ],
    "Hidalgo":[
            "Tizayuca",
            "Tolcayuca",
            "Villa de Tezontepec"
        ],
    "Morelos":[
            "Xochitepec"
        ],
    "Quintana Roo":[
            "Bacalar",
            "Chetumal",
            "Mineral de la Reforma"
        ]
}